\# Startcode for Java Deep Dive II week

Includes:

- IntelliJ setup
- JPA dependencies
- Lombok
- Junit 5
- Postgres drivers
- Test containers

Is created for Java 17 corretto

The Person entity is just for testing purposes and needs a ${IJ_BASE_PACKAGE}abase called "person" to work with JPA.


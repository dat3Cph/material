package enums;

public enum HibernateConfigState {
    NORMAL, TEST
}
